package practica2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class EventoSalir implements ActionListener {
  EventoSalir(VentanaPrincipalP2 paramVentanaPrincipalP2) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent) {
    System.exit(0);
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica2\C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */