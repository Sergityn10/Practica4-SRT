package practica2;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import srt.AboutBox;

/*class B implements ActionListener {
  VentanaPrincipalP2 ventanaPrincipal;

  B(VentanaPrincipalP2 paramVentanaPrincipalP2) {
    this.ventanaPrincipal = paramVentanaPrincipalP2;
  }
  
  public final void actionPerformed(ActionEvent paramActionEvent) {

    AboutBox aboutBox = new AboutBox(this.ventanaPrincipal.I(this.H));
    aboutBox.pack();
    Point point = this.getLocation.I().getLocation();
    point.translate(20, 20);
    aboutBox.setLocation(point);
    aboutBox.setVisible(true);
  }
}*/


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica2\B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */