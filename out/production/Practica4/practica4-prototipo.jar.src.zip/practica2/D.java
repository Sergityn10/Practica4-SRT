package practica2;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class D implements ActionListener {
  D(E paramE) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent) {
    OptionsDialog optionsDialog = new OptionsDialog(E.Z(this.getLocation));
    optionsDialog.pack();
    Point point = this.getLocation.I().getLocation();
    point.translate(20, 20);
    optionsDialog.setLocation(point);
    optionsDialog.setVisible(true);
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica2\D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */