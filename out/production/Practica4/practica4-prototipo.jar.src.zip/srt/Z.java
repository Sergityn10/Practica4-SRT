package srt;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class Z {
  private static final byte[] append = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
  
  private byte authenticationAlgorithms;
  
  private String cipherAlgorithms;
  
  private String close;
  
  private byte[] flush;
  
  public Z() {
    this.cipherAlgorithms = Options.cipherAlgorithms[0];
    this.close = Options.authenticationAlgorithms[0];
    this.authenticationAlgorithms = 0;
    this.flush = new byte[] { 125, 96, 67, 95, 2, 9, 15, 10 };
  }
  
  public Z(byte paramByte, String paramString1, String paramString2, byte[] paramArrayOfbyte) {
    this.authenticationAlgorithms = paramByte;
    this.cipherAlgorithms = paramString1;
    this.close = paramString2;
    this.flush = paramArrayOfbyte;
  }
  
  public final byte append() {
    return this.authenticationAlgorithms;
  }
  
  public final String I() {
    return this.cipherAlgorithms;
  }
  
  public final String Z() {
    return this.close;
  }
  
  public final byte[] C() {
    return this.flush;
  }
  
  public final boolean I(InputStream paramInputStream) {
    byte[] arrayOfByte = new byte[14];
    boolean bool = false;
    try {
      if (paramInputStream.read(arrayOfByte, 0, 14) == 14) {
        byte b;
        for (b = 0; b < 10 && arrayOfByte[b] == append[b]; b = (byte)(b + 1));
        if (b == 10) {
          b = (byte)(b + 1);
          this.authenticationAlgorithms = arrayOfByte[b];
          b = (byte)(b + 1);
          this.cipherAlgorithms = Options.cipherAlgorithms[arrayOfByte[b]];
          b = (byte)(b + 1);
          this.close = Options.authenticationAlgorithms[arrayOfByte[b]];
          b = (byte)(b + 1);
          byte b1 = arrayOfByte[b];
          this.flush = new byte[b1];
          if (paramInputStream.read(this.flush, 0, b1) == b1)
            bool = true; 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return bool;
  }
  
  public final boolean I(OutputStream paramOutputStream) {
    boolean bool = false;
    try {
      paramOutputStream.write(append);
      paramOutputStream.write(this.authenticationAlgorithms);
      paramOutputStream.write(Options.search(Options.cipherAlgorithms, this.cipherAlgorithms));
      paramOutputStream.write(Options.search(Options.authenticationAlgorithms, this.close));
      paramOutputStream.write(this.flush.length);
      paramOutputStream.write(this.flush, 0, this.flush.length);
      paramOutputStream.flush();
      bool = true;
    } catch (Exception exception) {}
    return bool;
  }
  
  public final void authenticationAlgorithms() {
    try {
      FileOutputStream fileOutputStream = new FileOutputStream("fileheader.prueba");
      I(fileOutputStream);
      fileOutputStream.close();
      Z z = new Z();
      FileInputStream fileInputStream = new FileInputStream("fileheader.prueba");
      if (z.I(fileInputStream)) {
        System.out.println("Leído, Operación: " + z.append());
        System.out.println("Leído, Algoritmo1: " + z.I());
        System.out.println("Leído, Algoritmo2: " + z.Z());
        System.out.print("Leído, Data     : ");
        for (byte b = 0; b < (z.C()).length; b = (byte)(b + 1)) {
          System.out.print(String.format("0x%h ", new Object[] { Byte.valueOf(z.C()[b]) }));
        } 
      } else {
        System.out.println("Error en la carga");
      } 
      fileInputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static final void main(String[] paramArrayOfString) {
    (new Z()).authenticationAlgorithms();
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\srt\Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */