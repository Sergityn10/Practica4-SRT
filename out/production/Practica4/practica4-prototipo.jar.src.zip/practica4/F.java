package practica4;

import javax.swing.SwingWorker;

class F extends SwingWorker {
  F(Practica4 paramPractica4, String paramString, Z paramZ) {}
  
  public final Void append() {
    try {
      this.append.G.I(this.getMessage, this.append.I(this.getMessage, "cif"), this.append.E.Z(), this.append.A.getPublicCipher(), this.getPublicCipher);
    } catch (Exception exception) {
      Practica4.Z(this.append).append(exception.getMessage());
    } 
    return null;
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica4\F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */