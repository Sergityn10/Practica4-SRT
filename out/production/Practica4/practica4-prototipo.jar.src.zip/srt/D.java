package srt;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JProgressBar;

class D extends KeyAdapter {
  D(PasswdDialog paramPasswdDialog, JProgressBar paramJProgressBar) {}
  
  public final void keyTyped(KeyEvent paramKeyEvent) {
    this.access$1.setValue(PasswdDialog.access$1(this.access$0, PasswdDialog.access$0(this.access$0).getPassword()));
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\srt\D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */