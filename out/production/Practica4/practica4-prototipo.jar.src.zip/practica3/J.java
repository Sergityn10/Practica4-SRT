package practica3;

class J implements Runnable {
  public final void run() {
    S s = new S();
    S.Z(s).setVisible(true);
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica3\J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */