package srt;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

class F implements ActionListener {
  F(PasswdDialog paramPasswdDialog, byte paramByte) {}
  
  public final void actionPerformed(ActionEvent paramActionEvent) {
    if (this.access$2 == 1) {
      if (Arrays.equals(PasswdDialog.access$0(this.access$0).getPassword(), PasswdDialog.access$2(this.access$0).getPassword())) {
        PasswdDialog.access$3(this.access$0, PasswdDialog.access$0(this.access$0).getPassword());
        this.access$0.setVisible(false);
      } 
    } else {
      PasswdDialog.access$3(this.access$0, PasswdDialog.access$0(this.access$0).getPassword());
      this.access$0.setVisible(false);
    } 
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\srt\F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */