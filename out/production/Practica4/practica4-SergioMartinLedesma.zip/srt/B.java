package srt;

public class B {
  private S Z = null;
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\srt\B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */