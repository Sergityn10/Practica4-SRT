package practica2;

class A implements Runnable {
  public final void run() {
    E e = new E();
    e.I().setVisible(true);
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica2\A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */