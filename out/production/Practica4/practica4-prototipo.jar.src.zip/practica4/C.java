package practica4;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import javax.crypto.Cipher;
import practica3.Z;
import srt.I;
import srt.Z;

public class C extends Z {
  private Practica4 append = null;
  
  public C() {}
  
  public C(Practica4 paramPractica4) {
    this.append = paramPractica4;
  }
  
  public final void I(String paramString1, String paramString2, PrivateKey paramPrivateKey, String paramString3, Z paramZ) {
    try {
      FileInputStream fileInputStream = new FileInputStream(paramString1);
      int j = 0;
      int k = fileInputStream.available();
      Signature signature = Signature.getInstance(paramString3);
      signature.initSign(paramPrivateKey);
      byte[] arrayOfByte1 = new byte[1024];
      int i;
      while ((i = fileInputStream.read(arrayOfByte1)) != -1) {
        j += i;
        signature.update(arrayOfByte1, 0, i);
        paramZ.I(j * 100 / k);
      } 
      byte[] arrayOfByte2 = signature.sign();
      paramZ.I("\nFirma (" + arrayOfByte2.length + " bytes): " + I.I(arrayOfByte2) + "\n");
      FileOutputStream fileOutputStream = new FileOutputStream(paramString2);
      fileInputStream.close();
      fileInputStream = new FileInputStream(paramString1);
      Z z = new Z((byte)30, "none", paramString3, arrayOfByte2);
      z.I(fileOutputStream);
      paramZ.I("\nEscribiendo fichero firmado: " + paramString2 + "\n");
      while ((i = fileInputStream.read(arrayOfByte1)) != -1)
        fileOutputStream.write(arrayOfByte1, 0, i); 
      fileOutputStream.close();
      fileInputStream.close();
    } catch (Exception exception) {
      throw exception;
    } 
  }
  
  public final boolean I(String paramString1, String paramString2, PublicKey paramPublicKey, Z paramZ) {
    boolean bool = false;
    try {
      FileOutputStream fileOutputStream = new FileOutputStream(paramString2);
      FileInputStream fileInputStream = new FileInputStream(paramString1);
      Z z = new Z();
      if (z.I(fileInputStream)) {
        int j = 0;
        int k = fileInputStream.available();
        paramZ.I("\nFirma original (" + (z.C()).length + " bytes): " + I.I(z.C()) + "\n");
        Signature signature = Signature.getInstance(z.Z());
        signature.initVerify(paramPublicKey);
        byte[] arrayOfByte = new byte[1024];
        int i;
        while ((i = fileInputStream.read(arrayOfByte)) != -1) {
          j += i;
          paramZ.I(j * 100 / k);
          signature.update(arrayOfByte, 0, i);
          fileOutputStream.write(arrayOfByte, 0, i);
        } 
        if (signature.verify(z.C())) {
          paramZ.I("\nFirma correcta.\n");
          bool = true;
        } else {
          paramZ.I("\nFirma no válida.\n");
          bool = false;
        } 
        fileOutputStream.close();
        fileInputStream.close();
      } 
    } catch (Exception exception) {
      throw exception;
    } 
    return bool;
  }
  
  public final void I(String paramString1, String paramString2, PublicKey paramPublicKey, String paramString3, Z paramZ) {
    try {
      FileOutputStream fileOutputStream = new FileOutputStream(paramString2);
      FileInputStream fileInputStream = new FileInputStream(paramString1);
      byte[] arrayOfByte1 = new byte[1];
      Z z = new Z((byte)20, paramString3, "none", arrayOfByte1);
      z.I(fileOutputStream);
      Cipher cipher = Cipher.getInstance(paramString3);
      cipher.init(1, paramPublicKey);
      byte b1 = 53;
      byte b2 = 0;
      int j = 0;
      int k = fileInputStream.available();
      byte[] arrayOfByte2 = new byte[b1];
      int i;
      while ((i = fileInputStream.read(arrayOfByte2)) != -1) {
        byte[] arrayOfByte = cipher.doFinal(arrayOfByte2, 0, i);
        fileOutputStream.write(arrayOfByte);
        b2++;
        j += i;
        paramZ.I(j * 100 / k);
      } 
      paramZ.I("\nCifrados " + b2 + " bloques; " + j + " bytes.\n");
      fileOutputStream.close();
      fileInputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public final void I(String paramString1, String paramString2, PrivateKey paramPrivateKey, Z paramZ) {
    try {
      FileOutputStream fileOutputStream = new FileOutputStream(paramString2);
      FileInputStream fileInputStream = new FileInputStream(paramString1);
      Z z = new Z();
      if (z.I(fileInputStream)) {
        Cipher cipher = Cipher.getInstance(z.I());
        cipher.init(2, paramPrivateKey);
        byte b1 = 64;
        byte b2 = 0;
        int j = 0;
        int k = fileInputStream.available();
        byte[] arrayOfByte = new byte[b1];
        int i;
        while ((i = fileInputStream.read(arrayOfByte)) != -1) {
          byte[] arrayOfByte1 = cipher.doFinal(arrayOfByte, 0, i);
          fileOutputStream.write(arrayOfByte1);
          b2++;
          j += i;
          paramZ.I(j * 100 / k);
        } 
        paramZ.I("\nDescifrados " + b2 + " bloques; " + j + " bytes.\n");
        fileOutputStream.close();
        fileInputStream.close();
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica4\C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */