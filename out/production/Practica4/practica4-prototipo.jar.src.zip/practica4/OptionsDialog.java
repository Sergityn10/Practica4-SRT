package practica4;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class OptionsDialog extends JDialog implements ActionListener {
  private static final long serialVersionUID = 1L;
  
  private Options options;
  
  JPanel panelPublicCiphers = new JPanel();
  
  JPanel panelDigitalSigners = new JPanel();
  
  JPanel panelPublicKeyFile = new JPanel();
  
  JPanel panelPasswdPublicKeyFile = new JPanel();
  
  JPanel panelKR = new JPanel();
  
  JPanel panelButton = new JPanel();
  
  JPanel panelSymmetricalCiphers = new JPanel();
  
  JPanel panelHashAlgorithms = new JPanel();
  
  JPanel panelSymmetricalAndHash = new JPanel();
  
  JButton buttonOK = new JButton();
  
  JButton buttonCancel = new JButton();
  
  JButton buttonExplore = new JButton();
  
  JLabel label1 = new JLabel();
  
  JLabel label2 = new JLabel();
  
  JLabel label3 = new JLabel();
  
  JLabel label4 = new JLabel();
  
  JLabel labelSymmetricalAlgorithm = new JLabel();
  
  JLabel labelHashAlgorithm = new JLabel();
  
  JTextField textField1 = new JTextField(20);
  
  JPasswordField passwdField = new JPasswordField("", 20);
  
  JComboBox jlPublicCiphers = new JComboBox<String>(Options.publicAlgorithms);
  
  JComboBox jlSigners = new JComboBox<String>(Options.signAlgorithms);
  
  JComboBox jlSymmetricalCiphers = new JComboBox<String>(Options.symmetricalAlgorithms);
  
  JComboBox jlHashs = new JComboBox<String>(Options.hashmacAlgorithms);
  
  public OptionsDialog(Options paramOptions) {
    this.options = paramOptions;
    enableEvents(64L);
    try {
      add();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    pack();
  }
  
  private void add() {
    setTitle("Opciones");
    setResizable(false);
    setModal(true);
    this.jlSymmetricalCiphers.setSelectedItem(this.options.getSymmetricalCipher());
    this.jlHashs.setSelectedItem(this.options.getAuthenticator());
    this.labelSymmetricalAlgorithm.setText("Algoritmo Cifrado PBE");
    this.labelHashAlgorithm.setText("Algoritmo Hash/HMac");
    this.panelSymmetricalCiphers.add(this.labelSymmetricalAlgorithm);
    this.panelSymmetricalCiphers.add(this.jlSymmetricalCiphers);
    this.panelSymmetricalCiphers.setBorder(BorderFactory.createEtchedBorder());
    this.panelHashAlgorithms.add(this.labelHashAlgorithm);
    this.panelHashAlgorithms.add(this.jlHashs);
    this.panelHashAlgorithms.setBorder(BorderFactory.createEtchedBorder());
    this.panelSymmetricalAndHash.add(this.panelSymmetricalCiphers);
    this.panelSymmetricalAndHash.add(this.panelHashAlgorithms);
    this.jlSymmetricalCiphers.setSelectedItem(this.options.getSymmetricalCipher());
    this.jlHashs.setSelectedItem(this.options.getAuthenticator());
    this.jlPublicCiphers.setSelectedItem(this.options.getPublicCipher());
    this.jlSigners.setSelectedItem(this.options.getSignAlgorithm());
    this.textField1.setText(this.options.getKeyFilename());
    this.passwdField.setText(new String(this.options.getKeyFilePasswd()));
    this.label2.setText("Algoritmo de Firma: ");
    this.label3.setText("Fichero de Claves: ");
    this.label4.setText("Contraseña: ");
    this.label1.setText("Cifrado Clave Pública: ");
    this.panelPublicCiphers.add(this.label1);
    this.panelPublicCiphers.add(this.jlPublicCiphers);
    this.panelPublicCiphers.setBorder(BorderFactory.createEtchedBorder());
    this.panelDigitalSigners.add(this.label2);
    this.panelDigitalSigners.add(this.jlSigners);
    this.panelDigitalSigners.setBorder(BorderFactory.createEtchedBorder());
    this.panelKR.add(this.panelPublicCiphers);
    this.panelKR.add(this.panelDigitalSigners);
    this.panelKR.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    this.panelPasswdPublicKeyFile.add(this.label4);
    this.panelPasswdPublicKeyFile.add(this.passwdField);
    this.panelPublicKeyFile.setLayout(new BorderLayout());
    this.panelPublicKeyFile.add(this.label3, "West");
    this.panelPublicKeyFile.add(this.textField1, "Center");
    this.panelPublicKeyFile.add(this.buttonExplore, "East");
    this.panelPublicKeyFile.add(this.panelPasswdPublicKeyFile, "South");
    this.panelPublicKeyFile.setBorder(BorderFactory.createEtchedBorder());
    this.buttonOK.setText("Aceptar");
    this.buttonCancel.setText("Cancelar");
    this.buttonExplore.setText("Examinar...");
    this.buttonOK.addActionListener(this);
    this.buttonCancel.addActionListener(this);
    this.buttonExplore.addActionListener(this);
    this.panelButton.add(this.buttonOK);
    this.panelButton.add(this.buttonCancel);
    this.panelButton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    getContentPane().setLayout(new GridLayout(4, 0));
    getContentPane().add(this.panelSymmetricalAndHash);
    getContentPane().add(this.panelKR);
    getContentPane().add(this.panelPublicKeyFile);
    getContentPane().add(this.panelButton);
  }
  
  protected final void processWindowEvent(WindowEvent paramWindowEvent) {
    if (paramWindowEvent.getID() == 201)
      cancel(); 
    super.processWindowEvent(paramWindowEvent);
  }
  
  private final void cancel() {
    dispose();
  }
  
  public final void actionPerformed(ActionEvent paramActionEvent) {
    if (paramActionEvent.getSource() == this.buttonOK) {
      this.options.setSymmetricalCipher((String)this.jlSymmetricalCiphers.getSelectedItem());
      this.options.setAuthenticator((String)this.jlHashs.getSelectedItem());
      this.options.setPublicCipher((String)this.jlPublicCiphers.getSelectedItem());
      this.options.setSignAlgorithm((String)this.jlSigners.getSelectedItem());
      this.options.setKeyFilename(this.textField1.getText());
      this.options.setKeyFilePasswd(this.passwdField.getPassword());
      try {
        this.options.save(Options.optionsFileName);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      cancel();
    } else if (paramActionEvent.getSource() == this.buttonExplore) {
      JFileChooser jFileChooser = new JFileChooser();
      jFileChooser.setDialogTitle("Fichero de claves");
      jFileChooser.setCurrentDirectory(new File("."));
      int i = jFileChooser.showOpenDialog(getContentPane());
      if (i == 0) {
        String str = jFileChooser.getSelectedFile().getAbsolutePath();
        this.options.setKeyFilename(str);
        this.textField1.setText(str);
      } 
    } 
    if (paramActionEvent.getSource() == this.buttonCancel)
      cancel(); 
  }
}


/* Location:              C:\Users\USUARIO\OneDrive - Universidad de Extremadura\Escritorio\Sergio\Uni\4º-curso\1º-cuatri\SRT\Prácticas-laboratorios\Entrega4\practica4-prototipo.jar!\practica4\OptionsDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */